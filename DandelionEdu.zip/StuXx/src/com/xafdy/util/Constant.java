package com.xafdy.util;

public class Constant {
	public static final Integer PAGESIZE = 30;
	
	public static final String AUTHSTR = "yi@qich!unj#iul$vs^hi&lid(ao#h.....au!!!xi##a$n@g";
}
